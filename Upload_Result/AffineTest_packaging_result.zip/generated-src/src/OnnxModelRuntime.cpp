#include "OnnxModelRuntime.h"
#include <fstream>
#include <cstring>
#include <algorithm>
#include <iostream>

using json = nlohmann::ordered_json;

static bool j_is_obj(const json& j) { return j.is_object(); }
static bool j_is_arr(const json& j) { return j.is_array(); }

static bool j_get_arr(const json& root, const char* key, const json*& out) {
    out = nullptr;
    if (!root.is_object()) return false;
    auto it = root.find(key);
    if (it == root.end() || !it->is_array()) return false;
    out = &(*it);
    return true;
}

static bool j_get_str(const json& obj, const char* key, std::string& out) {
    out.clear();
    if (!obj.is_object()) return false;
    auto it = obj.find(key);
    if (it == obj.end() || !it->is_string()) return false;
    out = it->get<std::string>();
    return true;
}

static bool j_get_i64(const json& obj, const char* key, int64_t& out) {
    out = 0;
    if (!obj.is_object()) return false;
    auto it = obj.find(key);
    if (it == obj.end() || !it->is_number_integer()) return false;
    out = it->get<int64_t>();
    return true;
}

static std::string shape_to_string(const std::vector<int64_t>& s) {
    std::string out = "[";
    for (size_t i = 0; i < s.size(); ++i) {
        out += std::to_string(s[i]);
        if (i + 1 < s.size()) out += ",";
    }
    out += "]";
    return out;
}

static char* twin_strdup(const std::string& s) {
#ifdef _WIN32
    return _strdup(s.c_str());
#else
    return ::strdup(s.c_str());
#endif
}

std::vector<int64_t> OnnxModelRuntime::jsonShapeToVector(const nlohmann::ordered_json& shapeJson) {
    std::vector<int64_t> shape;
    if (shapeJson.is_array()) {
        for (auto& v : shapeJson) {
            if (v.is_number_integer()) shape.push_back(v.get<int64_t>());
        }
    }
    if (shape.empty()) shape = { 1 };
    return shape;
}

size_t OnnxModelRuntime::safeElemCountFromShape(const std::vector<int64_t>& shape) {
    // For fixed shapes only. If shape has -1, caller must handle dynamically.
    if (shape.empty()) return 1;
    size_t count = 1;
    for (auto d : shape) {
        if (d <= 0) return 0; // invalid for fixed path (includes -1)
        count *= static_cast<size_t>(d);
    }
    return count;
}

bool OnnxModelRuntime::isStringType(const std::string& t) {
    return t == "String" || t == "string" || t == "STRING";
}

bool OnnxModelRuntime::tryParseJsonStringArray(const std::string& s, std::vector<std::string>& out, std::string& err) {
    out.clear();
    err.clear();
    try {
        auto j = json::parse(s);
        if (!j.is_array()) {
            err = "JSON is not array";
            return false;
        }
        for (auto& it : j) {
            if (!it.is_string()) {
                err = "JSON array contains non-string element";
                return false;
            }
            out.push_back(it.get<std::string>());
        }
        return true;
    }
    catch (const std::exception& e) {
        err = e.what();
        return false;
    }
}

OnnxModelRuntime::OnnxModelRuntime(const std::string& modelPath, const std::string& metadataJsonPath)
    : m_env(ORT_LOGGING_LEVEL_WARNING, "OnnxModelRuntime"),
      m_modelPath(modelPath) {

    std::ifstream fmeta(metadataJsonPath, std::ios::binary);
    if (!fmeta.is_open()) {
        m_lastError = "Cannot open metadata json: " + metadataJsonPath;
        return;
    }

    try {
        fmeta >> m_metadata;
    }
    catch (const std::exception& e) {
        m_lastError = std::string("Failed to parse metadata json: ") + e.what();
        return;
    }

    const json* inputs = nullptr;
    const json* outputs = nullptr;
    if (!j_get_arr(m_metadata, "inputs", inputs) || !j_get_arr(m_metadata, "outputs", outputs)) {
        m_lastError = "Metadata json missing 'inputs'/'outputs' arrays";
        return;
    }

    size_t flatOffset = 0;

    for (size_t i = 0; i < inputs->size(); ++i) {
        const json& in = (*inputs)[i];
        if (!j_is_obj(in)) { m_lastError = "inputs[" + std::to_string(i) + "] is not object"; return; }

        std::string name, dataType;
        int64_t idx64 = -1;

        if (!j_get_str(in, "name", name) || name.empty()) { m_lastError = "inputs[" + std::to_string(i) + "] missing name"; return; }
        if (!j_get_i64(in, "index", idx64) || idx64 < 0) { m_lastError = "inputs[" + std::to_string(i) + "] missing/invalid index"; return; }
        if (!j_get_str(in, "dataType", dataType) || dataType.empty()) { m_lastError = "inputs[" + std::to_string(i) + "] missing dataType"; return; }

        auto itShape = in.find("shape");
        if (itShape == in.end() || !itShape->is_array()) { m_lastError = "inputs[" + std::to_string(i) + "] missing shape"; return; }
        std::vector<int64_t> shape = jsonShapeToVector(*itShape);

        PortBinding pb;
        pb.ortIndex = static_cast<size_t>(idx64);
        pb.flatOffset = flatOffset;
        pb.shape = shape;
        pb.dataType = dataType;

        // �ж��Ƿ�Ϊ��̬��״������ά��Ϊ -1��
        bool isDynamic = false;
        for (auto d : shape) {
            if (d == -1) { isDynamic = true; break; }
        }

        if (isStringType(dataType)) {
            pb.elemCount = isDynamic ? 0 : safeElemCountFromShape(shape);
            if (!isDynamic && pb.elemCount == 0) {
                m_lastError = "Invalid fixed shape for string input " + name + ": " + shape_to_string(shape);
                return;
            }
        } else {
            if (isDynamic) {
                pb.elemCount = 0;            // ���Ϊ��̬
            } else {
                pb.elemCount = safeElemCountFromShape(shape);
                if (pb.elemCount == 0) {
                    m_lastError = "Invalid fixed shape for input " + name + ": " + shape_to_string(shape);
                    return;
                }
                flatOffset += pb.elemCount;
            }
        }
        m_inputs[name] = pb;

        char* dup = twin_strdup(name);
        m_inputNodeNamesOwned.push_back(dup);
        m_inputNodeNames.push_back(dup);
    }

    for (size_t i = 0; i < outputs->size(); ++i) {
        const json& out = (*outputs)[i];
        if (!j_is_obj(out)) { m_lastError = "outputs[" + std::to_string(i) + "] is not object"; return; }

        std::string name, dataType;
        int64_t idx64 = -1;

        if (!j_get_str(out, "name", name) || name.empty()) { m_lastError = "outputs[" + std::to_string(i) + "] missing name"; return; }
        if (!j_get_i64(out, "index", idx64) || idx64 < 0) { m_lastError = "outputs[" + std::to_string(i) + "] missing/invalid index"; return; }
        if (!j_get_str(out, "dataType", dataType) || dataType.empty()) { m_lastError = "outputs[" + std::to_string(i) + "] missing dataType"; return; }

        auto itShape = out.find("shape");
        if (itShape == out.end() || !itShape->is_array()) { m_lastError = "outputs[" + std::to_string(i) + "] missing shape"; return; }
        std::vector<int64_t> shape = jsonShapeToVector(*itShape);

        PortBinding pb;
        pb.ortIndex = static_cast<size_t>(idx64);
        pb.flatOffset = 0;
        pb.shape = shape;
        pb.dataType = dataType;

        const bool isDyn1D = (shape.size() == 1 && shape[0] == -1);
        if (isStringType(dataType)) pb.elemCount = isDyn1D ? 0 : safeElemCountFromShape(shape);
        else pb.elemCount = isDyn1D ? 0 : safeElemCountFromShape(shape);

        m_outputs[name] = pb;

        char* dup = twin_strdup(name);
        m_outputNodeNamesOwned.push_back(dup);
        m_outputNodeNames.push_back(dup);
    }

    m_inputValues.assign(flatOffset, 0.0);
    m_outputValues.clear();
}

OnnxModelRuntime::~OnnxModelRuntime() {
    terminate();
    for (auto p : m_inputNodeNamesOwned) free(p);
    for (auto p : m_outputNodeNamesOwned) free(p);
    m_inputNodeNamesOwned.clear();
    m_outputNodeNamesOwned.clear();
}

bool OnnxModelRuntime::init() {
    if (!m_lastError.empty()) return false;
    try {
        m_sessionOptions.SetIntraOpNumThreads(1);
#ifdef _WIN32
        std::wstring wpath(m_modelPath.begin(), m_modelPath.end());
        m_session = new Ort::Session(m_env, wpath.c_str(), m_sessionOptions);
#else
        m_session = new Ort::Session(m_env, m_modelPath.c_str(), m_sessionOptions);
#endif
        return true;
    }
    catch (const Ort::Exception& e) {
        m_lastError = e.what();
        return false;
    }
}

void OnnxModelRuntime::terminate() {
    delete m_session;
    m_session = nullptr;
}

std::vector<std::string> OnnxModelRuntime::getPortList() const {
    std::vector<std::string> ports;
    for (const auto& p : m_inputs) ports.push_back("IN:" + p.first);
    for (const auto& p : m_outputs) ports.push_back("OUT:" + p.first);
    return ports;
}

void OnnxModelRuntime::setRealInput(const std::string& portName, double value) {
    auto it = m_inputs.find(portName);
    if (it == m_inputs.end()) return;
    const auto& bind = it->second;
    if (isStringType(bind.dataType)) return;
    if (!bind.shape.empty() && bind.shape.size() == 1 && bind.shape[0] == -1) {
        // dynamic 1D: store single element as length=1 tensor
        m_tensorInputsF32[portName] = { static_cast<float>(value) };
        m_dynamicLen[portName] = 1;
        return;
    }
    if (bind.flatOffset < m_inputValues.size()) m_inputValues[bind.flatOffset] = value;
}

void OnnxModelRuntime::setIntInput(const std::string& portName, int value) {
    setRealInput(portName, static_cast<double>(value));
}

void OnnxModelRuntime::setBoolInput(const std::string& portName, bool value) {
    setIntInput(portName, value ? 1 : 0);
}

void OnnxModelRuntime::setStringInput(const std::string& portName, const std::string& value) {
    auto it = m_inputs.find(portName);
    if (it == m_inputs.end()) return;
    const auto& bind = it->second;
    if (!isStringType(bind.dataType)) return;

    std::vector<std::string> arr;
    std::string err;
    if (tryParseJsonStringArray(value, arr, err)) m_stringInputs[portName] = arr;
    else m_stringInputs[portName] = { value };

    // For dynamic 1D string tensor, record length for shape substitution
    if (!bind.shape.empty() && bind.shape.size() == 1 && bind.shape[0] == -1) {
        m_dynamicLen[portName] = static_cast<int64_t>(m_stringInputs[portName].size());
    }
}

void OnnxModelRuntime::setTensorInput(const std::string& portName, const std::vector<float>& tensorData) {
    auto it = m_inputs.find(portName);
    if (it == m_inputs.end()) { m_lastError = "Tensor port not found: " + portName; return; }
    const auto& bind = it->second;
    if (isStringType(bind.dataType)) { m_lastError = "TensorInput cannot set String port: " + portName; return; }

    // ʹ�� elemCount == 0 �ж϶�̬
    const bool isDynamic = (bind.elemCount == 0);
    if (isDynamic) {
        if (tensorData.empty()) {
            m_lastError = "Dynamic tensor cannot be empty: " + portName;
            return;
        }
        m_tensorInputsF32[portName] = tensorData;
        return;
    }

    if (bind.flatOffset + bind.elemCount > m_inputValues.size() || tensorData.size() != bind.elemCount) {
        m_lastError = "Tensor data size mismatch: " + portName;
        return;
    }
    for (size_t i = 0; i < tensorData.size(); ++i) m_inputValues[bind.flatOffset + i] = tensorData[i];
}

double OnnxModelRuntime::getRealOutput(const std::string& portName) const {
    // Keep behavior: if tensor output exists, return first element; else 0.
    auto it = m_tensorOutputsF32.find(portName);
    if (it != m_tensorOutputsF32.end() && !it->second.empty()) return static_cast<double>(it->second[0]);
    return 0.0;
}
int OnnxModelRuntime::getIntOutput(const std::string& portName) const { return static_cast<int>(getRealOutput(portName)); }
bool OnnxModelRuntime::getBoolOutput(const std::string& portName) const { return getRealOutput(portName) > 0.5; }

std::string OnnxModelRuntime::getStringOutput(const std::string& portName) const {
    auto it = m_stringOutputs.find(portName);
    if (it != m_stringOutputs.end()) {
        json j = json::array();
        for (auto& s : it->second) j.push_back(s);
        return j.dump();
    }
    return "";
}

std::vector<float> OnnxModelRuntime::getTensorOutputFloat32(const std::string& portName) const {
    auto it = m_tensorOutputsF32.find(portName);
    if (it != m_tensorOutputsF32.end()) return it->second;
    return {};
}

bool OnnxModelRuntime::run(double time, double stepSize) {
    (void)time; (void)stepSize;
    if (!m_session) { m_lastError = "session not initialized"; return false; }
    if (!m_lastError.empty()) return false;

    // Enforce: all dynamic 1D inputs share the same batch size (industry norm)
    // We infer batch size from first dynamic input that has been set.
    int64_t batchN = -1;
    for (const auto& kv : m_dynamicLen) {
        const auto& port = kv.first;
        const int64_t n = kv.second;
        auto itIn = m_inputs.find(port);
        if (itIn == m_inputs.end()) continue;
        const auto& bind = itIn->second;
        const bool isDyn1D = (!bind.shape.empty() && bind.shape.size() == 1 && bind.shape[0] == -1);
        if (!isDyn1D) continue;
        if (n <= 0) { m_lastError = "Dynamic length invalid for port: " + port; return false; }
        if (batchN < 0) batchN = n;
        else if (batchN != n) {
            m_lastError = "Dynamic batch mismatch: expected N=" + std::to_string(batchN) +
                          " but port '" + port + "' has N=" + std::to_string(n);
            return false;
        }
    }

    try {
        Ort::AllocatorWithDefaultOptions allocator;
        Ort::MemoryInfo mem = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);

        std::vector<Ort::Value> inputTensors;
        inputTensors.reserve(m_inputNodeNames.size());

        std::vector<std::vector<float>>   inFloatBuffers;
        std::vector<std::vector<double>>  inDoubleBuffers;
        std::vector<std::vector<int32_t>> inInt32Buffers;
        inFloatBuffers.reserve(m_inputNodeNames.size());
        inDoubleBuffers.reserve(m_inputNodeNames.size());
        inInt32Buffers.reserve(m_inputNodeNames.size());

        const json* inputs = nullptr;
        if (!j_get_arr(m_metadata, "inputs", inputs)) {
            m_lastError = "metadata inputs missing";
            return false;
        }

        for (size_t i = 0; i < inputs->size(); ++i) {
            const json& inMeta = (*inputs)[i];
            if (!j_is_obj(inMeta)) { m_lastError = "inputs[" + std::to_string(i) + "] is not object"; return false; }

            std::string portName, dataType;
            if (!j_get_str(inMeta, "name", portName) || !j_get_str(inMeta, "dataType", dataType)) {
                m_lastError = "invalid input meta at index " + std::to_string(i);
                return false;
            }

            auto itBind = m_inputs.find(portName);
            if (itBind == m_inputs.end()) { m_lastError = "missing input binding: " + portName; return false; }
            const PortBinding& bind = itBind->second;

            std::vector<int64_t> shape = bind.shape;
            // �ж��Ƿ�Ϊ��̬��״������ά�Ȱ��� -1��
            bool isDynamic = false;
            for (auto d : shape) {
                if (d == -1) { isDynamic = true; break; }
            }

            if (isStringType(dataType)) {
                // �ַ������봦������̬��̶���
                size_t elemCount = 0;
                if (isDynamic) {
                    auto itSI = m_stringInputs.find(portName);
                    if (itSI == m_stringInputs.end()) {
                        m_lastError = "Dynamic string input not set: " + portName;
                        return false;
                    }
                    elemCount = itSI->second.size();
                    // �Ƶ���̬ά��
                    int64_t staticProd = 1;
                    for (auto d : shape) if (d > 0) staticProd *= d;
                    if (staticProd == 0 || elemCount % staticProd != 0) {
                        m_lastError = "Cannot infer dynamic shape for string input: " + portName;
                        return false;
                    }
                    int64_t dynVal = static_cast<int64_t>(elemCount) / staticProd;
                    for (auto& d : shape) if (d == -1) d = dynVal;
                } else {
                    elemCount = bind.elemCount;
                }

                Ort::Value strTensor = Ort::Value::CreateTensor(
                    allocator, shape.data(), shape.size(), ONNX_TENSOR_ELEMENT_DATA_TYPE_STRING);

                std::vector<std::string> values;
                auto itSI = m_stringInputs.find(portName);
                if (itSI != m_stringInputs.end()) values = itSI->second;

                if (values.empty()) values.assign(elemCount, "");
                if (values.size() == 1 && elemCount > 1) values.assign(elemCount, values[0]);
                if (values.size() != elemCount) {
                    m_lastError = "String array element count mismatch: port=" + portName +
                                  " got=" + std::to_string(values.size()) + " expected=" + std::to_string(elemCount);
                    return false;
                }

                std::vector<const char*> cstrs(elemCount);
                for (size_t k = 0; k < elemCount; ++k) cstrs[k] = values[k].c_str();
                strTensor.FillStringTensor(cstrs.data(), cstrs.size());
                inputTensors.emplace_back(std::move(strTensor));
                continue;
            }

            // ��ֵ���Ͷ�̬����
            if (isDynamic) {
                auto itBuf = m_tensorInputsF32.find(portName);
                if (itBuf == m_tensorInputsF32.end()) {
                    m_lastError = "Dynamic tensor input not set: " + portName;
                    return false;
                }
                const auto& data = itBuf->second;
                if (data.empty()) {
                    m_lastError = "Dynamic tensor input is empty: " + portName;
                    return false;
                }

                // ���㾲̬ά�ȳ˻�
                int64_t staticProd = 1;
                for (auto d : shape) if (d > 0) staticProd *= d;
                if (staticProd == 0) {
                    // ����ά�ȶ��Ƕ�̬�ģ�ֱ��ʹ�����ݴ�С��Ϊ��״��չƽΪһά��
                    shape = { static_cast<int64_t>(data.size()) };
                } else {
                    if (data.size() % staticProd != 0) {
                        m_lastError = "Dynamic tensor size mismatch for port " + portName +
                                      ": data.size=" + std::to_string(data.size()) +
                                      ", staticProd=" + std::to_string(staticProd);
                        return false;
                    }
                    int64_t dynVal = static_cast<int64_t>(data.size()) / staticProd;
                    for (auto& d : shape) if (d == -1) d = dynVal;
                }

                if (dataType == "Float32") {
                    inputTensors.emplace_back(Ort::Value::CreateTensor<float>(
                        mem, const_cast<float*>(data.data()), data.size(), shape.data(), shape.size()));
                } else {
                    m_lastError = "Dynamic input supports Float32 only. port=" + portName + " type=" + dataType;
                    return false;
                }
                continue;
            }

            // fixed-shape numeric paths (use m_inputValues flat buffer)
            size_t offset = bind.flatOffset;
            size_t elemCount = bind.elemCount;

            if (dataType == "Float32") {
                inFloatBuffers.emplace_back(elemCount);
                auto& buffer = inFloatBuffers.back();
                for (size_t j = 0; j < elemCount; ++j) {
                    buffer[j] = std::visit([](auto&& v) -> float {
                        using T = std::decay_t<decltype(v)>;
                        if constexpr (std::is_same_v<T, std::string>) return 0.0f;
                        else return static_cast<float>(v);
                    }, m_inputValues[offset + j]);
                }
                inputTensors.emplace_back(Ort::Value::CreateTensor<float>(mem, buffer.data(), elemCount, shape.data(), shape.size()));
            }
            else if (dataType == "Float64" || dataType == "Double") {
                inDoubleBuffers.emplace_back(elemCount);
                auto& buffer = inDoubleBuffers.back();
                for (size_t j = 0; j < elemCount; ++j) {
                    buffer[j] = std::visit([](auto&& v) -> double {
                        using T = std::decay_t<decltype(v)>;
                        if constexpr (std::is_same_v<T, std::string>) return 0.0;
                        else return static_cast<double>(v);
                    }, m_inputValues[offset + j]);
                }
                inputTensors.emplace_back(Ort::Value::CreateTensor<double>(mem, buffer.data(), elemCount, shape.data(), shape.size()));
            }
            else if (dataType == "Int32" || dataType == "Int") {
                inInt32Buffers.emplace_back(elemCount);
                auto& buffer = inInt32Buffers.back();
                for (size_t j = 0; j < elemCount; ++j) {
                    buffer[j] = std::visit([](auto&& v) -> int32_t {
                        using T = std::decay_t<decltype(v)>;
                        if constexpr (std::is_same_v<T, std::string>) return 0;
                        else return static_cast<int32_t>(v);
                    }, m_inputValues[offset + j]);
                }
                inputTensors.emplace_back(Ort::Value::CreateTensor<int32_t>(mem, buffer.data(), elemCount, shape.data(), shape.size()));
            }
            else {
                m_lastError = "Unsupported input data type: " + dataType;
                return false;
            }
        }

        auto outputTensors = m_session->Run(
            Ort::RunOptions{ nullptr },
            m_inputNodeNames.data(), inputTensors.data(), inputTensors.size(),
            m_outputNodeNames.data(), m_outputNodeNames.size()
        );

        m_stringOutputs.clear();
        m_outputValues.clear();
        m_tensorOutputsF32.clear();

        const json* outputs = nullptr;
        if (!j_get_arr(m_metadata, "outputs", outputs)) {
            m_lastError = "metadata outputs missing";
            return false;
        }

        if (outputTensors.size() != outputs->size()) {
            m_lastError = "ORT output tensor count mismatch: got=" + std::to_string(outputTensors.size()) +
                          " expected=" + std::to_string(outputs->size());
            return false;
        }

        for (size_t oi = 0; oi < outputs->size(); ++oi) {
            const json& outMeta = (*outputs)[oi];
            if (!j_is_obj(outMeta)) { m_lastError = "outputs[" + std::to_string(oi) + "] is not object"; return false; }

            std::string outPortName, outType;
            if (!j_get_str(outMeta, "name", outPortName) || !j_get_str(outMeta, "dataType", outType)) {
                m_lastError = "invalid output meta at index " + std::to_string(oi);
                return false;
            }

            auto outInfo = outputTensors[oi].GetTensorTypeAndShapeInfo();
            size_t outCount = outInfo.GetElementCount();
            if (outCount == 0) outCount = 1;

            if (isStringType(outType)) {
                std::vector<std::string> vec;
                vec.reserve(outCount);
                for (size_t k = 0; k < outCount; ++k) {
                    size_t len = outputTensors[oi].GetStringTensorElementLength(k);
                    std::string s; s.resize(len);
                    outputTensors[oi].GetStringTensorElement(len, k, &s[0]);
                    vec.push_back(std::move(s));
                }
                m_stringOutputs[outPortName] = vec;
                m_outputValues.push_back(vec.empty() ? std::string("") : vec[0]);
                continue;
            }

            if (outType == "Float32") {
                const float* out = outputTensors[oi].GetTensorData<float>();
                m_outputValues.push_back(out[0]);
                std::vector<float> f32vec(outCount);
                for (size_t k = 0; k < outCount; ++k) f32vec[k] = out[k];
                m_tensorOutputsF32[outPortName] = std::move(f32vec);
            }
            else if (outType == "Float64" || outType == "Double") {
                const double* out = outputTensors[oi].GetTensorData<double>();
                m_outputValues.push_back(static_cast<float>(out[0]));
                std::vector<float> f32vec(outCount);
                for (size_t k = 0; k < outCount; ++k) f32vec[k] = static_cast<float>(out[k]);
                m_tensorOutputsF32[outPortName] = std::move(f32vec);
            }
            else if (outType == "Int32" || outType == "Int") {
                const int32_t* out = outputTensors[oi].GetTensorData<int32_t>();
                m_outputValues.push_back(static_cast<int>(out[0]));
                std::vector<float> f32vec(outCount);
                for (size_t k = 0; k < outCount; ++k) f32vec[k] = static_cast<float>(out[k]);
                m_tensorOutputsF32[outPortName] = std::move(f32vec);
            }
            else {
                m_lastError = "Unsupported output data type: " + outType;
                return false;
            }
        }

        return true;
    }
    catch (const Ort::Exception& e) {
        m_lastError = e.what();
        return false;
    }
    catch (const std::exception& e) {
        m_lastError = e.what();
        return false;
    }
}
