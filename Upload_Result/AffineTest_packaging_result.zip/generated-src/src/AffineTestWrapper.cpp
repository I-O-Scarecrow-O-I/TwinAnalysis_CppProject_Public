#include "AffineTestWrapper.h"
#include <filesystem>

namespace twin::generated {

AffineTestWrapper::~AffineTestWrapper(){
    release();
}

bool AffineTestWrapper::initialize(const std::string& modelPath, const std::string& metaJsonPath) {
    m_rt = std::make_unique<OnnxModelRuntime>(modelPath, metaJsonPath);
    if (!m_rt->init()) {
        m_lastError = m_rt->lastError();
        return false;
    }
    m_modelPath = modelPath;
    return true;
}

bool AffineTestWrapper::preprocess() { return true; }

bool AffineTestWrapper::infer(double time, double stepSize) {
    if (!m_rt) { m_lastError = "runtime not initialized"; return false; }
    if (!m_rt->run(time, stepSize)) { m_lastError = m_rt->lastError(); return false; }
    return true;
}

bool AffineTestWrapper::extractOutputs() { return true; }

void AffineTestWrapper::release() {
    if (m_rt) { m_rt->terminate(); m_rt.reset(); }
}

ModelStatus AffineTestWrapper::init() {
    // Runtime already initialised by initialize() – nothing extra needed
    return ModelStatus::OK;
}

ModelStatus AffineTestWrapper::configure(const std::string& configData) {
    namespace fs = std::filesystem;
    std::error_code ec;
    fs::path candidates[] = {
        fs::path("Packaging_Result") / "raw-extract" / "ModelParser_Meta.json",
        fs::path("raw-extract") / "ModelParser_Meta.json"
    };
    for (const auto& candidate : candidates) {
        if (fs::exists(candidate, ec)) {
            if (initialize(configData, candidate.string()))
                return ModelStatus::OK;
            else
                return ModelStatus::ERROR;
        }
    }
    m_lastError = "ModelParser_Meta.json not found";
    return ModelStatus::ERROR;
}

ModelStatus AffineTestWrapper::step(double time, double stepSize) {
    if (!m_rt) { m_lastError = "runtime not initialized"; return ModelStatus::ERROR; }
    if (!m_rt->run(time, stepSize)) {
        m_lastError = m_rt->lastError();
        return ModelStatus::ERROR;
    }
    return ModelStatus::OK;
}

ModelStatus AffineTestWrapper::reset() {
    release();
    if (m_modelPath.empty()) {
        m_lastError = "Cannot reset without a saved model path";
        return ModelStatus::ERROR;
    }
    return configure(m_modelPath);
}

ModelStatus AffineTestWrapper::terminate() {
    release();
    return ModelStatus::OK;
}

bool AffineTestWrapper::step(const Inputs& in, Outputs& out, double time, double stepSize) {
    if (!m_rt) { m_lastError = "runtime not initialized"; return false; }
    // Apply inputs
    m_rt->setTensorInput("input", in.x);
    if (!m_rt->run(time, stepSize)) { m_lastError = m_rt->lastError(); return false; }
    // Extract outputs
    out.y = m_rt->getTensorOutputFloat32("output_0");
    return true;
}

void AffineTestWrapper::setRealInput(const std::string& portName, double value) {
    if (m_rt) m_rt->setRealInput(portName, value);
}

double AffineTestWrapper::getRealOutput(const std::string& portName) const {
    return m_rt ? m_rt->getRealOutput(portName) : 0.0;
}

void AffineTestWrapper::setIntInput(const std::string& portName, int value) {
    if (m_rt) m_rt->setIntInput(portName, value);
}

int AffineTestWrapper::getIntOutput(const std::string& portName) const {
    return m_rt ? m_rt->getIntOutput(portName) : 0;
}

void AffineTestWrapper::setBoolInput(const std::string& portName, bool value) {
    if (m_rt) m_rt->setBoolInput(portName, value);
}

bool AffineTestWrapper::getBoolOutput(const std::string& portName) const {
    return m_rt ? m_rt->getBoolOutput(portName) : false;
}

void AffineTestWrapper::setStringInput(const std::string& portName, const std::string& value) {
    if (m_rt) m_rt->setStringInput(portName, value);
}

std::string AffineTestWrapper::getStringOutput(const std::string& portName) const {
    return m_rt ? m_rt->getStringOutput(portName) : "";
}

void AffineTestWrapper::setTensorInput(const std::string& portName, const std::vector<float>& tensorData) {
    if (m_rt) m_rt->setTensorInput(portName, tensorData);
}

std::string AffineTestWrapper::getBlockName() const {
    return m_blockName;
}

std::string AffineTestWrapper::getLastError() const {
    return m_lastError;
}

std::vector<std::string> AffineTestWrapper::getPortList() const {
    return m_rt ? m_rt->getPortList() : std::vector<std::string>();
}

} // namespace twin::generated
