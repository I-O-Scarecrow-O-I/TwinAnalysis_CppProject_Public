#pragma once
#include <string>
#include <vector>
#include <memory>
#include "OnnxModelRuntime.h"
#include "IModelBlock.h"

namespace twin::generated {

struct Inputs {
    std::vector<float> x{};
};

struct Outputs {
    std::vector<float> y{};
};

class AffineTestWrapper : public IModelBlock {
public:
    AffineTestWrapper() = default;
    ~AffineTestWrapper();

    // --- Original lifecycle (kept for internal convenience) ---
    bool initialize(const std::string& modelPath, const std::string& metaJsonPath);
    bool preprocess();
    bool infer(double time, double stepSize);
    bool extractOutputs();
    void release();

    // --- IModelBlock interface ---
    ModelStatus init() override;
    ModelStatus configure(const std::string& configData) override;
    ModelStatus step(double time, double stepSize) override;
    ModelStatus reset() override;
    ModelStatus terminate() override;

    void setRealInput(const std::string& portName, double value) override;
    double getRealOutput(const std::string& portName) const override;
    void setIntInput(const std::string& portName, int value) override;
    int getIntOutput(const std::string& portName) const override;
    void setBoolInput(const std::string& portName, bool value) override;
    bool getBoolOutput(const std::string& portName) const override;
    void setStringInput(const std::string& portName, const std::string& value) override;
    std::string getStringOutput(const std::string& portName) const override;
    void setTensorInput(const std::string& portName, const std::vector<float>& tensorData) override;

    std::string getBlockName() const override;
    std::string getLastError() const override;
    std::vector<std::string> getPortList() const override;

    // --- High‑level step with structured I/O (kept for easy testing) ---
    bool step(const Inputs& in, Outputs& out, double time, double stepSize);

    // backward compatible alias
    std::string lastError() const { return m_lastError; }

private:
    std::unique_ptr<OnnxModelRuntime> m_rt;
    std::string m_lastError;
    std::string m_blockName;
    std::string m_modelPath;   // stored for reset / reconfigure
};

} // namespace twin::generated
