#pragma once
#include "utils/json.hpp"
#include <onnxruntime_cxx_api.h>

#include <string>
#include <vector>
#include <map>
#include <variant>
#include <memory>

class OnnxModelRuntime {
public:
    OnnxModelRuntime(const std::string& modelPath, const std::string& metadataJsonPath);
    ~OnnxModelRuntime();

    bool init();
    bool run(double time, double stepSize);
    void terminate();

    // inputs
    void setRealInput(const std::string& portName, double value);
    void setIntInput(const std::string& portName, int value);
    void setBoolInput(const std::string& portName, bool value);
    void setStringInput(const std::string& portName, const std::string& value);
    void setTensorInput(const std::string& portName, const std::vector<float>& tensorData);

    // scalar outputs
    double getRealOutput(const std::string& portName) const;
    int getIntOutput(const std::string& portName) const;
    bool getBoolOutput(const std::string& portName) const;
    std::string getStringOutput(const std::string& portName) const;

    // full tensor output normalized to float32
    std::vector<float> getTensorOutputFloat32(const std::string& portName) const;

    std::vector<std::string> getPortList() const;
    std::string lastError() const { return m_lastError; }

private:
    struct PortBinding {
        size_t ortIndex = 0;
        size_t flatOffset = 0;
        size_t elemCount = 1;
        std::vector<int64_t> shape;
        std::string dataType;
    };

    static std::vector<int64_t> jsonShapeToVector(const nlohmann::ordered_json& shapeJson);
    static size_t safeElemCountFromShape(const std::vector<int64_t>& shape);
    static bool isStringType(const std::string& t);
    static bool tryParseJsonStringArray(const std::string& s, std::vector<std::string>& out, std::string& err);

private:
    Ort::Env m_env;
    Ort::Session* m_session = nullptr;
    Ort::SessionOptions m_sessionOptions;

    nlohmann::ordered_json m_metadata;

    std::map<std::string, PortBinding> m_inputs;
    std::map<std::string, PortBinding> m_outputs;

    std::vector<std::variant<float, double, int, std::string>> m_inputValues;
    std::vector<std::variant<float, double, int, std::string>> m_outputValues;

    std::map<std::string, std::vector<std::string>> m_stringInputs;
    std::map<std::string, std::vector<std::string>> m_stringOutputs;

    // Dynamic 1D tensor inputs (shape [-1]) stored here
    std::map<std::string, std::vector<float>> m_tensorInputsF32;
    std::map<std::string, int64_t> m_dynamicLen;

    // Full numeric tensor outputs normalized to float32
    std::map<std::string, std::vector<float>> m_tensorOutputsF32;

    std::vector<char*> m_inputNodeNamesOwned;
    std::vector<char*> m_outputNodeNamesOwned;
    std::vector<const char*> m_inputNodeNames;
    std::vector<const char*> m_outputNodeNames;

    std::string m_modelPath;
    std::string m_lastError;
};
