/**
 * @file IModelBlock.h
 * @brief ͳһģ�ͼܹ��ӿڶ��� (Universal Architecture Interface Contract - V2.0)
 * @author Architect Team (Module 1)
 */
#pragma once
#include <string>
#include <vector>
#include <map>

 // -------------------------------------------------------------------------
 // 1. ��׼״̬�붨��
 // -------------------------------------------------------------------------
enum class ModelStatus {
    OK = 0, WARNING = 1, ERROR = 2, FATAL = 3
};

// -------------------------------------------------------------------------
// 2. ͳһģ�ͽӿڻ��� (V2.0)
// -------------------------------------------------------------------------
class IModelBlock {
public:
    virtual ~IModelBlock() = default;

    // =================================================================
    // A. �������ڽӿ�
    // =================================================================
    virtual ModelStatus init() = 0;
    virtual ModelStatus configure(const std::string& configData) = 0;
    virtual ModelStatus step(double time, double stepSize) = 0;
    virtual ModelStatus reset() = 0;
    virtual ModelStatus terminate() = 0;

    // =================================================================
    // B. ���ݽ����ӿ� - ʵ��
    // =================================================================
    virtual void setRealInput(const std::string& portName, double value) = 0;
    virtual double getRealOutput(const std::string& portName) const = 0;

    // =================================================================
    // C. ���ݽ����ӿ� - ������ö��
    // =================================================================
    virtual void setIntInput(const std::string& portName, int value) = 0;
    virtual int getIntOutput(const std::string& portName) const = 0;

    // =================================================================
    // D. ���ݽ����ӿ� - ������
    // =================================================================
    virtual void setBoolInput(const std::string& portName, bool value) = 0;
    virtual bool getBoolOutput(const std::string& portName) const = 0;

    // =================================================================
    // E. ���ݽ����ӿ� - �ַ���
    // =================================================================
    virtual void setStringInput(const std::string& portName, const std::string& value) = 0;
    virtual std::string getStringOutput(const std::string& portName) const = 0;

    // =================================================================
    // F. ������ؽӿ�
    // =================================================================
    virtual std::string getBlockName() const = 0;
    virtual std::string getLastError() const = 0;
    virtual std::vector<std::string> getPortList() const = 0;

    // =================================================================
    // G. ���������ݽ����ӿ� - ����/ͼ�� (Tensor/Image)   ������ �ؼ���չ
    // ֧�ָ��Ӷ�ά���루��ͼ�����С�����ͼ�ȣ�
    // =================================================================
    virtual void setTensorInput(const std::string& portName, const std::vector<float>& tensorData) = 0;
};