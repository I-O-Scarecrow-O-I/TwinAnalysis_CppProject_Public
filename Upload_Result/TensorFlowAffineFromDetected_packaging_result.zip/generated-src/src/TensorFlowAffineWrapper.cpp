#include "TensorFlowAffineWrapper.h"
#include <filesystem>

namespace twin::generated {

TensorFlowAffineWrapper::~TensorFlowAffineWrapper(){
    release();
}

bool TensorFlowAffineWrapper::initialize(const std::string& modelPath, const std::string& metaJsonPath) {
    m_rt = std::make_unique<OnnxModelRuntime>(modelPath, metaJsonPath);
    if (!m_rt->init()) {
        m_lastError = m_rt->lastError();
        return false;
    }
    m_modelPath = modelPath;
    return true;
}

bool TensorFlowAffineWrapper::preprocess() { return true; }

bool TensorFlowAffineWrapper::infer(double time, double stepSize) {
    if (!m_rt) { m_lastError = "runtime not initialized"; return false; }
    if (!m_rt->run(time, stepSize)) { m_lastError = m_rt->lastError(); return false; }
    return true;
}

bool TensorFlowAffineWrapper::extractOutputs() { return true; }

void TensorFlowAffineWrapper::release() {
    if (m_rt) { m_rt->terminate(); m_rt.reset(); }
}

ModelStatus TensorFlowAffineWrapper::init() {
    // Runtime already initialised by initialize() – nothing extra needed
    return ModelStatus::OK;
}

ModelStatus TensorFlowAffineWrapper::configure(const std::string& configData) {
    namespace fs = std::filesystem;
    std::error_code ec;
    fs::path candidates[] = {
        fs::path("Packaging_Result") / "raw-extract" / "ModelParser_Meta.json",
        fs::path("raw-extract") / "ModelParser_Meta.json"
    };
    for (const auto& candidate : candidates) {
        if (fs::exists(candidate, ec)) {
            if (initialize(configData, candidate.string()))
                return ModelStatus::OK;
            else
                return ModelStatus::ERROR;
        }
    }
    m_lastError = "ModelParser_Meta.json not found";
    return ModelStatus::ERROR;
}

ModelStatus TensorFlowAffineWrapper::step(double time, double stepSize) {
    if (!m_rt) { m_lastError = "runtime not initialized"; return ModelStatus::ERROR; }
    if (!m_rt->run(time, stepSize)) {
        m_lastError = m_rt->lastError();
        return ModelStatus::ERROR;
    }
    return ModelStatus::OK;
}

ModelStatus TensorFlowAffineWrapper::reset() {
    release();
    if (m_modelPath.empty()) {
        m_lastError = "Cannot reset without a saved model path";
        return ModelStatus::ERROR;
    }
    return configure(m_modelPath);
}

ModelStatus TensorFlowAffineWrapper::terminate() {
    release();
    return ModelStatus::OK;
}

bool TensorFlowAffineWrapper::step(const Inputs& in, Outputs& out, double time, double stepSize) {
    if (!m_rt) { m_lastError = "runtime not initialized"; return false; }
    // Apply inputs
    m_rt->setTensorInput("input", in.x);
    if (!m_rt->run(time, stepSize)) { m_lastError = m_rt->lastError(); return false; }
    // Extract outputs
    out.y = m_rt->getTensorOutputFloat32("output_0");
    { auto _vec = m_rt->getTensorOutputFloat32("output_0"); int _idx = 0; out.y0 = (_idx >= 0 && static_cast<size_t>(_idx) < _vec.size()) ? static_cast<double>(_vec[_idx]) : double{}; }
    return true;
}

void TensorFlowAffineWrapper::setRealInput(const std::string& portName, double value) {
    if (m_rt) m_rt->setRealInput(portName, value);
}

double TensorFlowAffineWrapper::getRealOutput(const std::string& portName) const {
    return m_rt ? m_rt->getRealOutput(portName) : 0.0;
}

void TensorFlowAffineWrapper::setIntInput(const std::string& portName, int value) {
    if (m_rt) m_rt->setIntInput(portName, value);
}

int TensorFlowAffineWrapper::getIntOutput(const std::string& portName) const {
    return m_rt ? m_rt->getIntOutput(portName) : 0;
}

void TensorFlowAffineWrapper::setBoolInput(const std::string& portName, bool value) {
    if (m_rt) m_rt->setBoolInput(portName, value);
}

bool TensorFlowAffineWrapper::getBoolOutput(const std::string& portName) const {
    return m_rt ? m_rt->getBoolOutput(portName) : false;
}

void TensorFlowAffineWrapper::setStringInput(const std::string& portName, const std::string& value) {
    if (m_rt) m_rt->setStringInput(portName, value);
}

std::string TensorFlowAffineWrapper::getStringOutput(const std::string& portName) const {
    return m_rt ? m_rt->getStringOutput(portName) : "";
}

void TensorFlowAffineWrapper::setTensorInput(const std::string& portName, const std::vector<float>& tensorData) {
    if (m_rt) m_rt->setTensorInput(portName, tensorData);
}

std::string TensorFlowAffineWrapper::getBlockName() const {
    return m_blockName;
}

std::string TensorFlowAffineWrapper::getLastError() const {
    return m_lastError;
}

std::vector<std::string> TensorFlowAffineWrapper::getPortList() const {
    return m_rt ? m_rt->getPortList() : std::vector<std::string>();
}

} // namespace twin::generated
