#include "TorchModelRuntime.h"
#include <filesystem>
#include <fstream>

TorchModelRuntime::TorchModelRuntime(const std::string& modelPath)
    : m_modelPath(modelPath) {}

TorchModelRuntime::~TorchModelRuntime() { terminate(); }

bool TorchModelRuntime::init() {
    try {
        std::filesystem::path p(m_modelPath);
        std::ifstream ifs(p, std::ios::binary);
        if (!ifs.is_open()) {
            m_lastError = "Cannot open model file: " + m_modelPath;
            return false;
        }
        m_module = std::make_shared<torch::jit::Module>(torch::jit::load(ifs));
        m_module->eval();
        return true;
    } catch (const std::exception& e) {
        m_lastError = e.what();
        return false;
    }
}

bool TorchModelRuntime::run(const std::vector<torch::Tensor>& inputs,
                             std::vector<torch::Tensor>& outputs) {
    if (!m_module) {
        m_lastError = "Module not initialized";
        return false;
    }
    try {
        std::vector<c10::IValue> ivalue_inputs;
        ivalue_inputs.reserve(inputs.size());
        for (const auto& t : inputs)
            ivalue_inputs.emplace_back(t.contiguous());

        torch::jit::IValue result = m_module->forward(ivalue_inputs);

        if (result.isTuple()) {
            auto elems = result.toTuple()->elements();
            outputs.clear();
            for (auto& e : elems)
                outputs.push_back(e.toTensor().contiguous());
        } else if (result.isTensor()) {
            outputs = { result.toTensor().contiguous() };
        } else {
            m_lastError = "Unexpected model output type";
            return false;
        }
        return true;
    } catch (const std::exception& e) {
        m_lastError = e.what();
        return false;
    }
}

void TorchModelRuntime::terminate() {
    m_module.reset();
}
