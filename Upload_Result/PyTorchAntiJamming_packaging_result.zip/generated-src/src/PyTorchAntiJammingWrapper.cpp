#include "PyTorchAntiJammingWrapper.h"
#include <cstring>

namespace twin::generated {

PyTorchAntiJammingWrapper::~PyTorchAntiJammingWrapper() { terminate(); }

// ---------- original initialization ----------
bool PyTorchAntiJammingWrapper::initialize(const std::string& modelPath) {
    m_rt.reset(new TorchModelRuntime(modelPath));
    if (!m_rt->init()) {
        m_lastError = m_rt->lastError();
        return false;
    }
    m_modelPath = modelPath;
    return true;
}

// ---------- original structured step ----------
bool PyTorchAntiJammingWrapper::step(const Inputs& in, Outputs& out, double time, double stepSize) {
    (void)time; (void)stepSize;
    if (!m_rt) { m_lastError = "runtime not initialized"; return false; }

    try {
        std::vector<torch::Tensor> inputs;
        {
            const auto& data = in.input;
            std::vector<int64_t> shape = {1, 2, 10000};
            auto tensor = torch::from_blob(const_cast<float*>(data.data()), shape, torch::kFloat32).clone();
            inputs.push_back(tensor);
        }

        std::vector<torch::Tensor> outputs;
        if (!m_rt->run(inputs, outputs)) {
            m_lastError = m_rt->lastError();
            return false;
        }

        // Extract outputs by model order, map to fields
        if (0 < outputs.size()) {
            auto& t = outputs[0];
            out.output.assign(t.data_ptr<float>(), t.data_ptr<float>() + t.numel());
        }

        return true;
    } catch (const std::exception& e) {
        m_lastError = e.what();
        return false;
    }
}

// ========== IModelBlock overrides ==========
ModelStatus PyTorchAntiJammingWrapper::init() {
    // init is satisfied after a successful initialize; otherwise ERROR
    return ModelStatus::OK;
}

ModelStatus PyTorchAntiJammingWrapper::configure(const std::string& configData) {
    // configData = path to the .pt file
    if (initialize(configData))
        return ModelStatus::OK;
    return ModelStatus::ERROR;
}

ModelStatus PyTorchAntiJammingWrapper::step(double time, double stepSize) {
    (void)time; (void)stepSize;
    m_lastError = "Structured step (Inputs, Outputs) required for PyTorch model";
    return ModelStatus::ERROR;
}

ModelStatus PyTorchAntiJammingWrapper::reset() {
    terminate();
    if (!m_modelPath.empty()) {
        return configure(m_modelPath);
    }
    m_lastError = "No model path saved, cannot reset";
    return ModelStatus::ERROR;
}

ModelStatus PyTorchAntiJammingWrapper::terminate() {
    if (m_rt) {
        m_rt->terminate();
        m_rt.reset();
    }
    return ModelStatus::OK;
}

// ---------- scalar I/O (not supported) ----------
void PyTorchAntiJammingWrapper::setRealInput(const std::string& portName, double value) {
    m_lastError = "setRealInput not supported for PyTorch wrapper";
}
double PyTorchAntiJammingWrapper::getRealOutput(const std::string& portName) const {
    const_cast<std::string&>(m_lastError) = "getRealOutput not supported for PyTorch wrapper";
    return 0.0;
}
void PyTorchAntiJammingWrapper::setIntInput(const std::string& portName, int value) {
    m_lastError = "setIntInput not supported for PyTorch wrapper";
}
int PyTorchAntiJammingWrapper::getIntOutput(const std::string& portName) const {
    const_cast<std::string&>(m_lastError) = "getIntOutput not supported for PyTorch wrapper";
    return 0;
}
void PyTorchAntiJammingWrapper::setBoolInput(const std::string& portName, bool value) {
    m_lastError = "setBoolInput not supported for PyTorch wrapper";
}
bool PyTorchAntiJammingWrapper::getBoolOutput(const std::string& portName) const {
    const_cast<std::string&>(m_lastError) = "getBoolOutput not supported for PyTorch wrapper";
    return false;
}
void PyTorchAntiJammingWrapper::setStringInput(const std::string& portName, const std::string& value) {
    m_lastError = "setStringInput not supported for PyTorch wrapper";
}
std::string PyTorchAntiJammingWrapper::getStringOutput(const std::string& portName) const {
    const_cast<std::string&>(m_lastError) = "getStringOutput not supported for PyTorch wrapper";
    return "";
}
void PyTorchAntiJammingWrapper::setTensorInput(const std::string& portName, const std::vector<float>& tensorData) {
    // Tensor inputs are supported only through the structured step.
    m_lastError = "PyTorch wrapper uses structured step for tensor inputs; use step(Inputs, Outputs)";
}

// ---------- diagnostics ----------
std::string PyTorchAntiJammingWrapper::getBlockName() const {
    return m_blockName;
}
std::string PyTorchAntiJammingWrapper::getLastError() const {
    return m_lastError;
}
std::vector<std::string> PyTorchAntiJammingWrapper::getPortList() const {
    // PyTorch runtime doesn't expose named ports
    return {};
}

} // namespace twin::generated
