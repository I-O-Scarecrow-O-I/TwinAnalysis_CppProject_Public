#pragma once
#include "TorchModelRuntime.h"
#include "IModelBlock.h"
#include <string>
#include <vector>
#include <memory>

namespace twin::generated {

struct Inputs {
    std::vector<float> input{};
};

struct Outputs {
    std::vector<float> output{};
};

class PyTorchAntiJammingWrapper : public IModelBlock {
public:
    PyTorchAntiJammingWrapper() = default;
    ~PyTorchAntiJammingWrapper();

    // original lifecycle (kept for internal use)
    bool initialize(const std::string& modelPath);
    bool step(const Inputs& in, Outputs& out, double time, double stepSize);

    // IModelBlock overrides
    ModelStatus init() override;
    ModelStatus configure(const std::string& configData) override;
    ModelStatus step(double time, double stepSize) override;
    ModelStatus reset() override;
    ModelStatus terminate() override;

    void setRealInput(const std::string& portName, double value) override;
    double getRealOutput(const std::string& portName) const override;
    void setIntInput(const std::string& portName, int value) override;
    int getIntOutput(const std::string& portName) const override;
    void setBoolInput(const std::string& portName, bool value) override;
    bool getBoolOutput(const std::string& portName) const override;
    void setStringInput(const std::string& portName, const std::string& value) override;
    std::string getStringOutput(const std::string& portName) const override;
    void setTensorInput(const std::string& portName, const std::vector<float>& tensorData) override;

    std::string getBlockName() const override;
    std::string getLastError() const override;
    std::vector<std::string> getPortList() const override;

    // backward‑compatible shortcut
    std::string lastError() const { return m_lastError; }
private:
    std::unique_ptr<TorchModelRuntime> m_rt;
    std::string m_lastError;
    std::string m_blockName = "PyTorchAntiJammingWrapper";
    std::string m_modelPath;
};

} // namespace twin::generated
