#pragma once
#include <torch/script.h>
#include <string>
#include <vector>
#include <memory>

class TorchModelRuntime {
public:
    TorchModelRuntime(const std::string& modelPath);
    ~TorchModelRuntime();

    bool init();
    bool run(const std::vector<torch::Tensor>& inputs,
             std::vector<torch::Tensor>& outputs);
    void terminate();
    std::string lastError() const { return m_lastError; }

private:
    std::string m_modelPath;
    std::shared_ptr<torch::jit::Module> m_module;
    std::string m_lastError;
};
